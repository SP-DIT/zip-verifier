function createQueueSystem() {
    // Your code here
    return { 
        queue: [], nextNumber: 1, takeANumber: function() 
        { const number = this.nextNumber; this.queue.push(number); this.nextNumber++; return number; 

        }, serveNextCustomer: function ()
         { if (this.queue.length === 0) { return null;} return this.queue.shift();}, getCurrentQueue: function() 
            { return this.queue; } };
}

module.exports = createQueueSystem;

// Example usage:
const queue = createQueueSystem();
console.log(queue.takeANumber()); // 1
console.log(queue.takeANumber()); // 2
console.log(queue.getCurrentQueue()); // [1, 2]
console.log(queue.serveNextCustomer()); // 1
console.log(queue.getCurrentQueue()); // [2]
console.log(queue.takeANumber()); // 3
console.log(queue.getCurrentQueue()); // [2, 3]
