function createCharacter(maxHealth) {
    // Your code here

    { return {
         maxHealth: maxHealth, health: maxHealth, takeDamage: function(amount)
          { this.health -= amount; 
            if (this.health < 0) 
                { this.health = 0; } 
            return this.health; 
        }, heal: function(amount) 
        { this.health += amount; 
            if (this.health > this.maxHealth) 
                { this.health = this.maxHealth;

                 } return this.health; }, getHealth: function()
                  { return this.health; }, isAlive: function() 
                  { return this.health > 0; } };
}
}

module.exports = createCharacter;

// Example usage:
const character = createCharacter(100); // maxHealth of 100
console.log(character.takeDamage(30)); // 70, character takes 30 damage and has 70 health left
console.log(character.heal(20)); // 90, character heals 20 and has 90 health
console.log(character.getHealth()); // 90, current health is 90
console.log(character.isAlive()); // true, character is alive
console.log(character.takeDamage(80)); // 10, character takes 80 damage and has 10 health left
console.log(character.heal(120)); // 100, character heals 120 but health caps at maxHealth of 100
console.log(character.takeDamage(999)); // 0, character takes 999 damage and health drops to 0
console.log(character.isAlive()); // false, character is dead
