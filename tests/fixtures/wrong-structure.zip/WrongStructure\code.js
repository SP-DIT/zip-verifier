// Wrong structure - missing proper assignment folder structure
function someFunction() {
    return "This is in wrong structure";
}

module.exports = someFunction;