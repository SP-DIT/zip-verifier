module.exports = {
    testcases: [
        {
            input: [],
            expected: "This is in wrong structure",
            isPublic: true,
            description: "Wrong structure test"
        }
    ]
};