// incorrect syntax
function addNumbers(a, b) {
    whle (true) {}
}

module.exports = addNumbers;
