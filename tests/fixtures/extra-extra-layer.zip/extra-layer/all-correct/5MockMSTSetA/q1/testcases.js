module.exports = {
    testcases: [
        {
            input: [2, 3],
            expected: 5,
            isPublic: true,
            description: "Test basic addition"
        },
        {
            input: [-1, 1],
            expected: 0,
            isPublic: true,
            description: "Test zero result"
        },
        {
            input: [10, 20],
            expected: 30,
            isPublic: false,
            description: "Hidden test case"
        }
    ]
};