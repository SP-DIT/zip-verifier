// Sample assignment with all correct answers
function addNumbers(a, b) {
    return a + b;
}

module.exports = addNumbers;