module.exports = {
    testcases: [
        {
            input: [2, 3],
            expected: 6,
            isPublic: true,
            description: "Test basic multiplication"
        },
        {
            input: [0, 5],
            expected: 0,
            isPublic: true,
            description: "Test zero multiplication"
        },
        {
            input: [4, 5],
            expected: 20,
            isPublic: false,
            description: "Hidden test case"
        }
    ]
};