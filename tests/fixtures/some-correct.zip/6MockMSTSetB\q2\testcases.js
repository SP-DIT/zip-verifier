module.exports = {
    testcases: [
        {
            input: [2, 3],
            expected: 6,
            isPublic: true,
            description: "Test basic multiplication"
        },
        {
            input: [4, 5],
            expected: 20,
            isPublic: true,
            description: "Test another multiplication"
        }
    ]
};