// Correct solution for q1
function addNumbers(a, b) {
    return a + b;
}

module.exports = addNumbers;