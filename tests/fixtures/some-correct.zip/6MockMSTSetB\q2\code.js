// Wrong solution for q2 - returns addition instead of multiplication
function multiplyNumbers(a, b) {
    return a + b; // This is wrong! Should be a * b
}

module.exports = multiplyNumbers;