// infinite loop
function addNumbers(a, b) {
    while (true) {}
}

module.exports = addNumbers;
