module.exports = {
    testcases: [
        {
            input: [6, 2],
            expected: 12,
            isPublic: true,
            description: "Test multiplication"
        },
        {
            input: [8, 4],
            expected: 32,
            isPublic: false,
            description: "Hidden multiplication test"
        }
    ]
};