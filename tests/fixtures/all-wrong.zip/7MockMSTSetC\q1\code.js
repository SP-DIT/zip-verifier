// Wrong solution - returns subtraction instead of addition
function addNumbers(a, b) {
    return a - b; // This is wrong!
}

module.exports = addNumbers;