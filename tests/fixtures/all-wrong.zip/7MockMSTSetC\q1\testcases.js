module.exports = {
    testcases: [
        {
            input: [5, 3],
            expected: 8,
            isPublic: true,
            description: "Test addition"
        },
        {
            input: [10, 15],
            expected: 25,
            isPublic: true,
            description: "Test large numbers"
        }
    ]
};