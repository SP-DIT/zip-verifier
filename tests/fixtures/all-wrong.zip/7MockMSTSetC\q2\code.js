// Wrong solution - returns division instead of multiplication
function multiplyNumbers(a, b) {
    return a / b; // This is wrong!
}

module.exports = multiplyNumbers;