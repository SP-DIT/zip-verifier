module.exports = {
    testcases: [
        {
            input: [2, [5, 3, 8], 10],
            expected: { destination: 8, completed: 3, chargedPowerLeft: 0 },
            isPublic: true,
            description: 'complete all requests with enough charged power',
        },
        {
            input: [4, [7, 2, 9], 8],
            expected: { destination: 2, completed: 2, chargedPowerLeft: 0 },
            isPublic: true,
            description: 'complete some requests with none left charged power',
        },
        {
            input: [3, [6, 8, 14], 9],
            expected: { destination: 8, completed: 2, chargedPowerLeft: 4 },
            isPublic: true,
            description: 'complete some requests with limited charged power',
        },
        {
            input: [1, [4], 4],
            expected: { destination: 4, completed: 1, chargedPowerLeft: 1 },
            isPublic: false,
            description: 'single request completed exactly',
        },
        {
            input: [1, [4], 3],
            expected: { destination: 4, completed: 1, chargedPowerLeft: 0 },
            isPublic: false,
            description: 'single request completed with 0 power unit left',
        },
        {
            input: [1, [4], 2],
            expected: { destination: 1, completed: 0, chargedPowerLeft: 2 },
            isPublic: false,
            description: 'single request not completed due to insufficient power',
        },
        {
            input: [5, [1, 2, 3, 4, 5], 8],
            expected: { destination: 5, completed: 5, chargedPowerLeft: 0 },
            isPublic: false,
            description: 'complete all requests when power exactly matches total',
        },
        {
            input: [5, [1, 2, 3, 4, 5], 7],
            expected: { destination: 4, completed: 4, chargedPowerLeft: 0 },
            isPublic: false,
            description: 'complete all requests except the last one',
        },
        {
            input: [5, [1, 2, 3, 4, 5], 4],
            expected: { destination: 1, completed: 1, chargedPowerLeft: 0 },
            isPublic: false,
            description: 'completed 1 request with no remaining power left',
        },
        {
            input: [2, [10, 2], 16],
            expected: { destination: 2, completed: 2, chargedPowerLeft: 0 },
            isPublic: false,
            description: 'complete all requests with enough charged power',
        },
    ],
    options: {
        type: 'JSON',
    },
};
