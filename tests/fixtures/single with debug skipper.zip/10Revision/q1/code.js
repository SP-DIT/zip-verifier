function deliveryBotJourney(startDestination, requests, chargedPower) {
    var curr = startDestination, completed = 0;
    for (let i = 0; i < requests.length; i++) {
        if (chargedPower >= Math.abs(curr - requests[i])) {
            chargedPower -= Math.abs(curr - requests[i]);
            curr = requests[i];
            completed++;
        } else break;
    }

    return {destination: curr, completed: completed, chargedPowerLeft: chargedPower};
}

module.exports = deliveryBotJourney;

// Examples
if (process.env.SKIP_SAMPLE_TESTS === 'true') return; // Can ignore; Used to skip sample tests when debugging specific test cases

console.log(deliveryBotJourney(2, [5, 3, 8], 10));
// {
//   destination: 8,
//   completed: 3,
//   chargedPowerLeft: 0
// }

console.log(deliveryBotJourney(4, [7, 2, 9], 8));
// {
//   destination: 2,
//   completed: 2,
//   chargedPowerLeft: 0
// }

console.log(deliveryBotJourney(3, [6, 8, 14], 9));
// {
//   destination: 8,
//   completed: 2,
//   chargedPowerLeft: 4
// }

console.log(deliveryBotJourney(1, [4], 4));
// {
//   destination: 4,
//   completed: 1,
//   chargedPowerLeft: 0
// }

console.log(deliveryBotJourney(1, [4], 2));
// {
//   destination: 0,
//   completed: 0,
//   chargedPowerLeft: 2
// }

console.log(deliveryBotJourney(5, [1, 2, 3, 4, 5], 8));
// {
//   destination: 5,
//   completed: 5,
//   chargedPowerLeft: 0
// }

module.exports = deliveryBotJourney;
