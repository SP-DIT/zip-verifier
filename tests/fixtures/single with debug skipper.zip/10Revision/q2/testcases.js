﻿module.exports = {
    testcases: [
        {
            input: [
                [
                    { row: 'A', seatsLeft: 6 },
                    { row: 'B', seatsLeft: 4 },
                    { row: 'C', seatsLeft: 8 },
                ],
                [3],
            ],
            expected: ['B'],
            isPublic: true,
            description: 'single match',
        },
        {
            input: [
                [
                    { row: 'A', seatsLeft: 5 },
                    { row: 'B', seatsLeft: 7 },
                    { row: 'C', seatsLeft: 4 },
                ],
                [3, 2, 4],
            ],
            expected: ['C', 'A', 'B'],
            isPublic: true,
            description: 'multiple matches',
        },
        {
            input: [
                [
                    { row: 'A', seatsLeft: 5 },
                    { row: 'B', seatsLeft: 5 },
                    { row: 'C', seatsLeft: 8 },
                ],
                [4],
            ],
            expected: ['A'],
            isPublic: true,
            description: 'single match with equal seats',
        },
        {
            input: [
                [
                    { row: 'A', seatsLeft: 3 },
                    { row: 'B', seatsLeft: 2 },
                    { row: 'C', seatsLeft: 4 },
                ],
                [5, 2],
            ],
            expected: ['unassigned', 'B'],
            isPublic: true,
            description: 'unassigned case',
        },
        {
            input: [
                [
                    { row: 'A', seatsLeft: 4 },
                    { row: 'B', seatsLeft: 2 },
                    { row: 'C', seatsLeft: 6 },
                ],
                [2, 2],
            ],
            expected: ['B', 'A'],
            isPublic: false,
            description: 'choose the row with the smallest available seats that fits',
        },
        {
            input: [
                [
                    { row: 'A', seatsLeft: 1 },
                    { row: 'B', seatsLeft: 2 },
                    { row: 'C', seatsLeft: 3 },
                ],
                [1, 1, 1],
            ],
            expected: ['A', 'B', 'B'],
            isPublic: false,
            description: 'reuse the same row when it still fits the next request',
        },
        {
            input: [
                [
                    { row: 'A', seatsLeft: 8 },
                    { row: 'B', seatsLeft: 4 },
                    { row: 'C', seatsLeft: 2 },
                ],
                [2, 2],
            ],
            expected: ['C', 'B'],
            isPublic: false,
            description: 'select the row with the fewest remaining seats after a full-row match',
        },
        {
            input: [
                [
                    { row: 'A', seatsLeft: 5 },
                    { row: 'B', seatsLeft: 5 },
                    { row: 'C', seatsLeft: 5 },
                ],
                [4, 4],
            ],
            expected: ['A', 'B'],
            isPublic: false,
            description: 'tie-break by row order when multiple rows can fit',
        },
        {
            input: [
                [
                    { row: 'A', seatsLeft: 7 },
                    { row: 'B', seatsLeft: 4 },
                    { row: 'C', seatsLeft: 5 },
                ],
                [3, 1, 2],
            ],
            expected: ['B', 'B', 'C'],
            isPublic: false,
            description: 'multiple requests with changing remaining capacities',
        },
        {
            input: [
                [
                    { row: 'A', seatsLeft: 2 },
                    { row: 'B', seatsLeft: 3 },
                    { row: 'C', seatsLeft: 4 },
                ],
                [5, 2, 1],
            ],
            expected: ['unassigned', 'A', 'B'],
            isPublic: false,
            description: 'mixed case with an unassigned request followed by successful matches',
        },
    ],
    options: {
        type: 'JSON',
    },
};
