function assignSeats(rows, groups) {
    let assignments = [];
    for (let i = 0; i < groups.length; i++) {
        let minrow = -1;
        for (let j = 0; j < rows.length; j++) {
            if (rows[j].seatsLeft >= groups[i] && (minrow == -1 || rows[j].seatsLeft < rows[minrow].seatsLeft)) {
                minrow = j;
            }
        }
        
        if (minrow == -1) assignments.push("unassigned");
        else {
            assignments.push(rows[minrow].row);
            rows[minrow].seatsLeft -= groups[i];
        }
    }
    return assignments;
}

module.exports = assignSeats;

// Examples
if (process.env.SKIP_SAMPLE_TESTS === 'true') return; // Can ignore; Used to skip sample tests when debugging specific test cases

console.log(
    assignSeats(
        [
            { row: 'A', seatsLeft: 6 },
            { row: 'B', seatsLeft: 4 },
            { row: 'C', seatsLeft: 8 },
        ],
        [3],
    ),
);
// ["B"]

console.log(
    assignSeats(
        [
            { row: 'A', seatsLeft: 5 },
            { row: 'B', seatsLeft: 7 },
            { row: 'C', seatsLeft: 4 },
        ],
        [3, 2, 4],
    ),
);
// ["C", "A", "B"]

console.log(
    assignSeats(
        [
            { row: 'A', seatsLeft: 5 },
            { row: 'B', seatsLeft: 5 },
            { row: 'C', seatsLeft: 8 },
        ],
        [4],
    ),
);
// ["A"]

console.log(
    assignSeats(
        [
            { row: 'A', seatsLeft: 3 },
            { row: 'B', seatsLeft: 2 },
            { row: 'C', seatsLeft: 4 },
        ],
        [5, 2],
    ),
);
// ["unassigned", "B"]
