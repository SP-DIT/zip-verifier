﻿module.exports = {
  testcases: [
    {
      input: [
        [
          {
            name: "Team A",
            answers: ["A", "C", "B", "-", "D"],
          },
          {
            name: "Team B",
            answers: ["A", "B", "C", "B", "A"],
          },
          {
            name: "Team C",
            answers: ["B", "C", "C", "B", "D"],
          },
        ],
        ["A", "C", "C", "B", "D"],
      ],
      expected: "Team C",
      isPublic: true,
      description: "one team has the highest score",
    },
    {
      input: [
        [
          {
            name: "Team Red",
            answers: ["B", "B", "A", "C", "D"],
          },
          {
            name: "Team Blue",
            answers: ["A", "B", "A", "C", "B"],
          },
        ],
        ["A", "C", "D", "B", "A"],
      ],
      expected: "No winner",
      isPublic: true,
      description: "no team has a positive score",
    },
    {
      input: [
        [
          {
            name: "Team A",
            answers: ["A", "B", "C", "D"],
          },
          {
            name: "Team B",
            answers: ["A", "B", "C", "D"],
          },
          {
            name: "Team C",
            answers: ["A", "C", "B", "D"],
          },
        ],
        ["A", "B", "C", "D"],
      ],
      expected: "Multiple winners",
      isPublic: true,
      description: "multiple teams have the same highest score",
    },
    {
      input: [
        [
          {
            name: "Team A",
            answers: ["A", "B", "C"],
          },
          {
            name: "Team B",
            answers: ["A", "-", "C"],
          },
          {
            name: "Team C",
            answers: ["A", "C", "-"],
          },
        ],
        ["A", "B", "C"],
      ],
      expected: "Team A",
      isPublic: false,
      description: "single winner when one team is fully correct",
    },
    {
      input: [
        [
          {
            name: "Team A",
            answers: ["A", "-", "-"],
          },
          {
            name: "Team B",
            answers: ["-", "C", "B"],
          },
          {
            name: "Team C",
            answers: ["A", "C", "B"],
          },
        ],
        ["A", "C", "B"],
      ],
      expected: "Team C",
      isPublic: false,
      description: "single winner with a mix of correct, wrong, and missing answers",
    },
    {
      input: [
        [
          {
            name: "Team A",
            answers: ["-", "-"],
          },
          {
            name: "Team B",
            answers: ["-", "-"],
          },
          {
            name: "Team C",
            answers: ["-", "-"],
          },
        ],
        ["A", "B"],
      ],
      expected: "No winner",
      isPublic: false,
      description: "no winner when all scores stay at zero",
    },
    {
      input: [
        [
          {
            name: "Team A",
            answers: ["A", "B"],
          },
          {
            name: "Team B",
            answers: ["A", "B"],
          },
          {
            name: "Team C",
            answers: ["A", "-"],
          },
        ],
        ["A", "B"],
      ],
      expected: "Multiple winners",
      isPublic: false,
      description: "multiple winners with a tie at the highest positive score",
    },
    {
      input: [
        [
          {
            name: "Team A",
            answers: ["A", "-", "C", "-"],
          },
          {
            name: "Team B",
            answers: ["-", "B", "-", "D"],
          },
          {
            name: "Team C",
            answers: ["A", "B", "-", "D"],
          },
        ],
        ["A", "B", "C", "D"],
      ],
      expected: "Team C",
      isPublic: false,
      description: "winner with missing answers and a strong correct streak",
    },
    {
      input: [
        [
          {
            name: "Team A",
            answers: ["-", "B", "C"],
          },
          {
            name: "Team B",
            answers: ["A", "-", "C"],
          },
          {
            name: "Team C",
            answers: ["A", "B", "-"],
          },
        ],
        ["A", "B", "C"],
      ],
      expected: "Multiple winners",
      isPublic: false,
      description: "three teams tie at the same positive score",
    },
    {
      input: [
        [
          {
            name: "Team A",
            answers: ["A", "C", "-"],
          },
          {
            name: "Team B",
            answers: ["-", "-", "D"],
          },
          {
            name: "Team C",
            answers: ["-", "-", "-"],
          },
        ],
        ["A", "C", "D"],
      ],
      expected: "Team A",
      isPublic: false,
      description: "single winner with one team scoring zero and another lower",
    },
  ],
  options: {
    type: "JSON",
  },
};
