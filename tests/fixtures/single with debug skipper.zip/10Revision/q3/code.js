function teamQuiz(teams, correctAnswers) {
    let scores = [];
    for (let i = 0; i < teams.length; i++) {
        let teamscore = 0;
        for (let j = 0; j < correctAnswers.length; j++) {
            if (teams[i].answers[j] == correctAnswers[j]) {
                teamscore += 2;
            } else if (teamscore >= 1 && teams[i].answers[j] != "-") {
                teamscore -= 1;
            }
        }
        scores.push(teamscore);
    }

    let maxscore = scores[0];
    let maxteams = [teams[0].name];
    for (let i = 1; i < scores.length; i++) {
        if (scores[i] > maxscore) {
            maxscore = scores[i];
            maxteams = [teams[i].name];
        } else if (scores[i] == maxscore) {
            maxteams.push(teams[i].name);
        }
    }

    if (maxscore == 0) {
        return "No winner";
    } else if (maxteams.length > 1) {
        return "Multiple winners";
    } else {
        return maxteams[0]; 
    }
}

module.exports = teamQuiz;

// Examples
if (process.env.SKIP_SAMPLE_TESTS === 'true') return; // Can ignore; Used to skip sample tests when debugging specific test cases

console.log(
    teamQuiz(
        [
            {
                name: 'Team A',
                answers: ['A', 'C', 'B', '-', 'D'],
            },
            {
                name: 'Team B',
                answers: ['A', 'B', 'C', 'B', 'A'],
            },
            {
                name: 'Team C',
                answers: ['B', 'C', 'C', 'B', 'D'],
            },
        ],
        ['A', 'C', 'C', 'B', 'D'],
    ),
);
// "Team C"

console.log(
    teamQuiz(
        [
            {
                name: 'Team Red',
                answers: ['B', 'B', 'A', 'C', 'D'],
            },
            {
                name: 'Team Blue',
                answers: ['A', 'B', 'A', 'C', 'B'],
            },
        ],
        ['A', 'C', 'D', 'B', 'A'],
    ),
);
// "No winner"

console.log(
    teamQuiz(
        [
            {
                name: 'Team A',
                answers: ['A', 'B', 'C', 'D'],
            },
            {
                name: 'Team B',
                answers: ['A', 'B', 'C', 'D'],
            },
            {
                name: 'Team C',
                answers: ['A', 'C', 'B', 'D'],
            },
        ],
        ['A', 'B', 'C', 'D'],
    ),
);
// "Multiple winners"
