module.exports = {
    testcases: [
        // Public test cases (first 3)
        {
            input: [[1, 2, 3, 4, 5]],
            expected: [5],
            isPublic: true,
            description: 'Filter [1, 2, 3, 4, 5] should result in [5]',
        },
        {
            input: [[1, 2, 3]],
            expected: [],
            isPublic: true,
            description: 'Filter [1, 2, 3] should result in empty array',
        },
        {
            input: [[6]],
            expected: [6],
            isPublic: true,
            description: 'Filter [6] should result in [6]',
        },
        // Hidden test cases
        {
            input: [[]],
            expected: [],
            isPublic: false,
            description: 'Empty array should result in empty array',
        },
        {
            input: [[5]],
            expected: [5],
            isPublic: false,
            description: 'Boundary case: [5] should result in [5]',
        },
        {
            input: [[4.99]],
            expected: [],
            isPublic: false,
            description: 'Boundary case: [4.99] should result in empty array',
        },
        {
            input: [[5.01]],
            expected: [5.01],
            isPublic: false,
            description: 'Boundary case: [5.01] should result in [5.01]',
        },
        {
            input: [[10, 20, 30]],
            expected: [10, 20, 30],
            isPublic: false,
            description: 'All values >= 5: [10, 20, 30] should result in [10, 20, 30]',
        },
        {
            input: [[1, 2, 3, 4]],
            expected: [],
            isPublic: false,
            description: 'All values < 5: [1, 2, 3, 4] should result in empty array',
        },
        {
            input: [[0, -1, -5]],
            expected: [],
            isPublic: false,
            description: 'Negative values: [0, -1, -5] should result in empty array',
        },
        {
            input: [[1, 5, 2, 8, 3, 10]],
            expected: [5, 8, 10],
            isPublic: false,
            description: 'Mixed values: [1, 5, 2, 8, 3, 10] should result in [5, 8, 10]',
        },
        {
            input: [[5, 5, 5]],
            expected: [5, 5, 5],
            isPublic: false,
            description: 'Multiple boundary values: [5, 5, 5] should result in [5, 5, 5]',
        },
        {
            input: [[4.5, 5.5, 6.5]],
            expected: [5.5, 6.5],
            isPublic: false,
            description: 'Decimal values: [4.5, 5.5, 6.5] should result in [5.5, 6.5]',
        },
        {
            input: [[100, 50, 25, 12.5, 6.25]],
            expected: [100, 50, 25, 12.5, 6.25],
            isPublic: false,
            description: 'Large values: [100, 50, 25, 12.5, 6.25] should result in [100, 50, 25, 12.5, 6.25]',
        },
        {
            input: [[1, 4, 5, 3, 6, 2, 7]],
            expected: [5, 6, 7],
            isPublic: false,
            description: 'Alternating pattern: [1, 4, 5, 3, 6, 2, 7] should result in [5, 6, 7]',
        },
        {
            input: [[4, 4, 4, 4]],
            expected: [],
            isPublic: false,
            description: 'All same value below 5: [4, 4, 4, 4] should result in empty array',
        },
        {
            input: [[6, 6, 6, 6]],
            expected: [6, 6, 6, 6],
            isPublic: false,
            description: 'All same value above 5: [6, 6, 6, 6] should result in [6, 6, 6, 6]',
        },
        {
            input: [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]],
            expected: [5, 6, 7, 8, 9, 10],
            isPublic: false,
            description: 'Sequential numbers 0-10: should filter to [5, 6, 7, 8, 9, 10]',
        },
        {
            input: [[-10, -5, 0, 5, 10]],
            expected: [5, 10],
            isPublic: false,
            description: 'Mix of negative and positive: [-10, -5, 0, 5, 10] should result in [5, 10]',
        },
        {
            input: [[4.999, 5.001]],
            expected: [5.001],
            isPublic: false,
            description: 'Very close to boundary: [4.999, 5.001] should result in [5.001]',
        },
    ],
    options: {
        type: 'JSON',
    },
};
