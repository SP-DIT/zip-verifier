function sumArray(arr) {
    // your code here
}

module.exports = sumArray;

// examples
console.log(sumArray([1, 2, 3])); // 6
console.log(sumArray([3, 6, 9, 12, 15])); // 45
console.log(sumArray([])); // 0
