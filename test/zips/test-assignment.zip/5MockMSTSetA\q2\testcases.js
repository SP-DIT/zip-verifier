module.exports = {
    testcases: [
        // Public test cases (first 3)
        {
            input: [[90, 100, 120]],
            expected: [90, 100, 96],
            isPublic: true,
            description: 'Discount [90, 100, 120] should result in [90, 100, 96]',
        },
        {
            input: [[150, 300]],
            expected: [120, 240],
            isPublic: true,
            description: 'Discount [150, 300] should result in [120, 240]',
        },
        {
            input: [[]],
            expected: [],
            isPublic: true,
            description: 'Empty array should result in empty array',
        },
        // Hidden test cases
        {
            input: [[100]],
            expected: [100],
            isPublic: false,
            description: 'Boundary case: $100 should remain $100 (no discount)',
        },
        {
            input: [[125]],
            expected: [100],
            isPublic: false,
            description: 'Clear discount case: $125 should get 20% discount = $100',
        },
        {
            input: [[99]],
            expected: [99],
            isPublic: false,
            description: 'Just below boundary: $99 should remain unchanged',
        },
        {
            input: [[105]],
            expected: [84],
            isPublic: false,
            description: 'Above boundary: $105 should get 20% discount = $84',
        },
        {
            input: [[50, 75, 25, 80]],
            expected: [50, 75, 25, 80],
            isPublic: false,
            description: 'All prices ≤ $100: [50, 75, 25, 80] should remain unchanged',
        },
        {
            input: [[110, 150, 200]],
            expected: [88, 120, 160],
            isPublic: false,
            description: 'All prices > $100: [110, 150, 200] should be [88, 120, 160]',
        },
        {
            input: [[10, 50, 120, 200]],
            expected: [10, 50, 96, 160],
            isPublic: false,
            description: 'Mixed prices: [10, 50, 120, 200] should be [10, 50, 96, 160]',
        },
        {
            input: [[125]],
            expected: [100],
            isPublic: false,
            description: 'Simple discount: $125 should get 20% discount = $100',
        },
        {
            input: [[250]],
            expected: [200],
            isPublic: false,
            description: 'Large amount: $250 should get 20% discount = $200',
        },
        {
            input: [[500, 1000]],
            expected: [400, 800],
            isPublic: false,
            description: 'Very large amounts: [500, 1000] should be [400, 800]',
        },
        {
            input: [[99, 100, 125]],
            expected: [99, 100, 100],
            isPublic: false,
            description: 'Boundary test: [99, 100, 125] should be [99, 100, 100]',
        },
        {
            input: [[100, 100, 100]],
            expected: [100, 100, 100],
            isPublic: false,
            description: 'Multiple boundary values: [100, 100, 100] should remain unchanged',
        },
        {
            input: [[125, 125, 125]],
            expected: [100, 100, 100],
            isPublic: false,
            description: 'Multiple discount values: [125, 125, 125] should be [100, 100, 100]',
        },
        {
            input: [[0, 50, 100, 150]],
            expected: [0, 50, 100, 120],
            isPublic: false,
            description: 'Including zero: [0, 50, 100, 150] should be [0, 50, 100, 120]',
        },
        {
            input: [[110, 120]],
            expected: [88, 96],
            isPublic: false,
            description: 'Clean decimal prices: [110, 120] should be [88, 96]',
        },
        {
            input: [[75, 85, 95, 105, 115, 125]],
            expected: [75, 85, 95, 84, 92, 100],
            isPublic: false,
            description: 'Alternating pattern: [75, 85, 95, 105, 115, 125] should be [75, 85, 95, 84, 92, 100]',
        },
        {
            input: [[1000, 2000, 3000]],
            expected: [800, 1600, 2400],
            isPublic: false,
            description: 'High-value items: [1000, 2000, 3000] should be [800, 1600, 2400]',
        },
    ],
    options: {
        type: 'JSON',
    },
};
