function discount(arr) {
    // your code here
}

module.exports = discount;

// examples
console.log(discount([90, 100, 120])); // [90, 100, 96]
console.log(discount([150, 300])); // [120, 240]
console.log(discount([])); // []
