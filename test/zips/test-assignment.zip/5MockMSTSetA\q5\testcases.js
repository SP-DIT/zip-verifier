module.exports = {
    testcases: [
        // Public test cases (first 3)
        {
            input: ['apple'],
            expected: 'fuuqj',
            isPublic: true,
            description: 'Caesar cipher of "apple" should be "fuuqj"',
        },
        {
            input: ['zig zag'],
            expected: 'enl efl',
            isPublic: true,
            description: 'Caesar cipher of "zig zag" should be "enl efl"',
        },
        {
            input: ['hello world'],
            expected: 'mjqqt btwqi',
            isPublic: true,
            description: 'Caesar cipher of "hello world" should be "mjqqt btwqi"',
        },
        // Hidden test cases
        {
            input: [''],
            expected: '',
            isPublic: false,
            description: 'Caesar cipher of empty string should be empty string',
        },
        {
            input: [' '],
            expected: ' ',
            isPublic: false,
            description: 'Caesar cipher of single space should be single space',
        },
        {
            input: ['a'],
            expected: 'f',
            isPublic: false,
            description: 'Caesar cipher of "a" should be "f"',
        },
        {
            input: ['z'],
            expected: 'e',
            isPublic: false,
            description: 'Caesar cipher of "z" should be "e" (wrap around)',
        },
        {
            input: ['xyz'],
            expected: 'cde',
            isPublic: false,
            description: 'Caesar cipher of "xyz" should be "cde" (all wrap around)',
        },
        {
            input: ['abcde'],
            expected: 'fghij',
            isPublic: false,
            description: 'Caesar cipher of "abcde" should be "fghij"',
        },
        {
            input: ['vwxyz'],
            expected: 'abcde',
            isPublic: false,
            description: 'Caesar cipher of "vwxyz" should be "abcde" (all wrap around)',
        },
        {
            input: ['  '],
            expected: '  ',
            isPublic: false,
            description: 'Caesar cipher of multiple spaces should preserve spaces',
        },
        {
            input: ['a b c'],
            expected: 'f g h',
            isPublic: false,
            description: 'Caesar cipher of "a b c" should be "f g h"',
        },
        {
            input: ['programming'],
            expected: 'uwtlwfrrnsl',
            isPublic: false,
            description: 'Caesar cipher of "programming" should be "uwtlwfrrnsl"',
        },
        {
            input: ['quick brown fox'],
            expected: 'vznhp gwtbs ktc',
            isPublic: false,
            description: 'Caesar cipher of "quick brown fox" should be "vznhp gwtbs ktc"',
        },
        {
            input: ['the lazy dog'],
            expected: 'ymj qfed itl',
            isPublic: false,
            description: 'Caesar cipher of "the lazy dog" should be "ymj qfed itl"',
        },
        {
            input: ['aaaaaa'],
            expected: 'ffffff',
            isPublic: false,
            description: 'Caesar cipher of repeated "a" should be repeated "f"',
        },
        {
            input: ['zzzzzz'],
            expected: 'eeeeee',
            isPublic: false,
            description: 'Caesar cipher of repeated "z" should be repeated "e"',
        },
        {
            input: ['test case'],
            expected: 'yjxy hfxj',
            isPublic: false,
            description: 'Caesar cipher of "test case" should be "yjxy hfxj"',
        },
        {
            input: ['m n o p q'],
            expected: 'r s t u v',
            isPublic: false,
            description: 'Caesar cipher of "m n o p q" should be "r s t u v"',
        },
        {
            input: ['code'],
            expected: 'htij',
            isPublic: false,
            description: 'Caesar cipher of "code" should be "htij"',
        },
    ],
    options: {
        type: 'JSON',
    },
};
