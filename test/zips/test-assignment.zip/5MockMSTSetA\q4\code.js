// Copy your solution from Question 1: Filter items with values >= 5
function filterLessThan5(arr) {
    // Copy your solution from q1 here
}

// Copy your solution from Question 2: Apply 20% discount for items > $100
function discount(arr) {
    // Copy your solution from q2 here
}

// Copy your solution from Question 3: Sum all numbers in array
function sumArray(arr) {
    // Copy your solution from q3 here
}

function calculateFinalPrice(items) {}

module.exports = calculateFinalPrice;

// examples
console.log(calculateFinalPrice([1, 120, 90, 4, 100, 105])); // 370
console.log(calculateFinalPrice([3, 50, 150, 2])); // 170
console.log(calculateFinalPrice([200, 75, 4.5])); // 235
console.log(calculateFinalPrice([1, 2, 3, 4])); // 0
