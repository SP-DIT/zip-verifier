module.exports = {
    testcases: [
        // Public test cases (first 3)
        {
            input: [[1, 2, 3]],
            expected: 6,
            isPublic: true,
            description: 'Sum of [1, 2, 3] should be 6',
        },
        {
            input: [[3, 6, 9, 12, 15]],
            expected: 45,
            isPublic: true,
            description: 'Sum of [3, 6, 9, 12, 15] should be 45',
        },
        {
            input: [[]],
            expected: 0,
            isPublic: true,
            description: 'Sum of empty array should be 0',
        },
        // Hidden test cases
        {
            input: [[0]],
            expected: 0,
            isPublic: false,
            description: 'Sum of [0] should be 0',
        },
        {
            input: [[5]],
            expected: 5,
            isPublic: false,
            description: 'Sum of single element [5] should be 5',
        },
        {
            input: [[-1, -2, -3]],
            expected: -6,
            isPublic: false,
            description: 'Sum of negative numbers [-1, -2, -3] should be -6',
        },
        {
            input: [[1, -1, 2, -2]],
            expected: 0,
            isPublic: false,
            description: 'Sum of mixed positive/negative [1, -1, 2, -2] should be 0',
        },
        {
            input: [[10, 20, 30, 40, 50]],
            expected: 150,
            isPublic: false,
            description: 'Sum of [10, 20, 30, 40, 50] should be 150',
        },
        {
            input: [[1, 1, 1, 1, 1]],
            expected: 5,
            isPublic: false,
            description: 'Sum of repeated values [1, 1, 1, 1, 1] should be 5',
        },
        {
            input: [[100]],
            expected: 100,
            isPublic: false,
            description: 'Sum of single large number [100] should be 100',
        },
        {
            input: [[-5, 10, -3, 8]],
            expected: 10,
            isPublic: false,
            description: 'Sum of mixed numbers [-5, 10, -3, 8] should be 10',
        },
        {
            input: [[0, 0, 0, 5]],
            expected: 5,
            isPublic: false,
            description: 'Sum with zeros [0, 0, 0, 5] should be 5',
        },
        {
            input: [[7, 14, 21, 28]],
            expected: 70,
            isPublic: false,
            description: 'Sum of multiples [7, 14, 21, 28] should be 70',
        },
        {
            input: [[2, 4, 6, 8, 10]],
            expected: 30,
            isPublic: false,
            description: 'Sum of even numbers [2, 4, 6, 8, 10] should be 30',
        },
        {
            input: [[1, 3, 5, 7, 9]],
            expected: 25,
            isPublic: false,
            description: 'Sum of odd numbers [1, 3, 5, 7, 9] should be 25',
        },
        {
            input: [[-10, -20, -30]],
            expected: -60,
            isPublic: false,
            description: 'Sum of all negative [-10, -20, -30] should be -60',
        },
        {
            input: [[25, 25, 25, 25]],
            expected: 100,
            isPublic: false,
            description: 'Sum of identical values [25, 25, 25, 25] should be 100',
        },
        {
            input: [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]],
            expected: 55,
            isPublic: false,
            description: 'Sum of 1-10 should be 55',
        },
        {
            input: [[15, -5, 8, -3, 12]],
            expected: 27,
            isPublic: false,
            description: 'Sum of complex mix [15, -5, 8, -3, 12] should be 27',
        },
        {
            input: [[50, 60, 70, 80, 90]],
            expected: 350,
            isPublic: false,
            description: 'Sum of large numbers [50, 60, 70, 80, 90] should be 350',
        },
    ],
    options: {
        type: 'JSON',
    },
};
