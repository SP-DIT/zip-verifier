function filterLessThan5(arr) {
    return arr.filter(num => num >= 5);
}

module.exports = filterLessThan5;

// examples
console.log(filterLessThan5([1, 2, 3, 4, 5])); // [5]
console.log(filterLessThan5([1, 2, 3])); // []
console.log(filterLessThan5([6])); // [6]
