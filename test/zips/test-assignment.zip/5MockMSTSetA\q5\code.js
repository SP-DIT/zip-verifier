function stringLength(string) {
    // This function is already implemented for you
    // get's the number of character in the string
    return string.length;
}

function charAt(str, i) {
    // This function is already implemented for you
    // get's the ith character in the string
    return str[i];
}

function positionOfCharacter(char) {
    // This function is already implemented for you
    // Given a lowercase alphabet, returns the 0-index position of the alphabet (e.g. a => 0, b => 1, x => 23, y => 24, z => 25)
    return 'abcdefghijklmnopqrstuvwxyz'.split('').indexOf(char);
}

function characterAtPosition(position) {
    // This function is already implemented for you
    // Given a 0-index position, returns the corresponding alphabet (e.g. 0 => a, 1 => b, 23 => x, 24 => y, 25 => z)
    return charAt('abcdefghijklmnopqrstuvwxyz', position);
}

function caesarCipher(message) {
    // your code here
}

module.exports = caesarCipher;

// examples

console.log(caesarCipher('apple')); // "fuuqj"
console.log(caesarCipher('zig zag')); // "enl efl"
