function howMuchLeftOver(n, requests) {
    // your code here
}

module.exports = howMuchLeftOver;

// examples

console.log(howMuchLeftOver(10, [1, 3, 7, 4, 5])); // 2
console.log(howMuchLeftOver(15, [2, 8, 3, 6])); // 2
console.log(howMuchLeftOver(5, [10, 2, 3])); // 0
console.log(howMuchLeftOver(20, [5, 5, 5, 5])); // 0
