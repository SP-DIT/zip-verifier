module.exports = {
    testcases: [
        // Public test cases (first 3)
        {
            input: [[1, 120, 90, 4, 100, 105]],
            expected: 370,
            isPublic: true,
            description: 'Final price for [1, 120, 90, 4, 100, 105] should be 370',
        },
        {
            input: [[3, 50, 150, 2]],
            expected: 170,
            isPublic: true,
            description: 'Final price for [3, 50, 150, 2] should be 170',
        },
        {
            input: [[200, 75, 4.5]],
            expected: 235,
            isPublic: true,
            description: 'Final price for [200, 75, 4.5] should be 235',
        },
        // Hidden test cases
        {
            input: [[1, 2, 3, 4]],
            expected: 0,
            isPublic: false,
            description: 'All free items [1, 2, 3, 4] should result in total 0',
        },
        {
            input: [[]],
            expected: 0,
            isPublic: false,
            description: 'Empty input should result in total 0',
        },
        {
            input: [[5]],
            expected: 5,
            isPublic: false,
            description: 'Boundary case: $5 should result in total 5',
        },
        {
            input: [[100]],
            expected: 100,
            isPublic: false,
            description: 'Boundary case: $100 should result in total 100',
        },
        {
            input: [[125]],
            expected: 100,
            isPublic: false,
            description: 'Discount case: $125 should result in total 100',
        },
        {
            input: [[4.99]],
            expected: 0,
            isPublic: false,
            description: 'Boundary case: $4.99 should be free, total 0',
        },
        {
            input: [[5.01]],
            expected: 5.01,
            isPublic: false,
            description: 'Boundary case: $5.01 should result in total 5.01',
        },
        {
            input: [[50, 75, 25, 80]],
            expected: 230,
            isPublic: false,
            description: 'Regular prices [50, 75, 25, 80] should sum to 230',
        },
        {
            input: [[110, 150, 200]],
            expected: 368,
            isPublic: false,
            description: 'All discounted items [110, 150, 200] should sum to 368 (88+120+160)',
        },
        {
            input: [[10, 1, 50, 2, 120]],
            expected: 156,
            isPublic: false,
            description: 'Mixed case: [10, 1, 50, 2, 120] should sum to 156 (10+50+96)',
        },
        {
            input: [[4, 99, 125]],
            expected: 199,
            isPublic: false,
            description: 'Clean boundaries: [4, 99, 125] should sum to 199 (99+100)',
        },
        {
            input: [[250]],
            expected: 200,
            isPublic: false,
            description: 'Large amount: $250 should result in total 200',
        },
        {
            input: [[15, 85, 115]],
            expected: 192,
            isPublic: false,
            description: 'Three categories: [15, 85, 115] should sum to 192 (15+85+92)',
        },
        {
            input: [[4, 4, 4, 4, 4]],
            expected: 0,
            isPublic: false,
            description: 'Multiple free items should result in total 0',
        },
        {
            input: [[6, 7, 8, 9, 10]],
            expected: 40,
            isPublic: false,
            description: 'Small regular prices [6, 7, 8, 9, 10] should sum to 40',
        },
        {
            input: [[125, 175, 225]],
            expected: 420,
            isPublic: false,
            description: 'Large amounts [125, 175, 225] should sum to 420 (100+140+180)',
        },
        {
            input: [[2.5, 50, 150, 3.75]],
            expected: 170,
            isPublic: false,
            description: 'Mixed decimals: [2.5, 50, 150, 3.75] should sum to 170 (50+120)',
        },
    ],
    options: {
        type: 'JSON',
    },
};
