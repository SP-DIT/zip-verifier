module.exports = {
    testcases: [
        // Public test cases (first 3)
        {
            input: [10, [1, 3, 7, 4, 5]],
            expected: 2,
            isPublic: true,
            description: 'Durian seller with 10 durians and requests [1, 3, 7, 4, 5] should have 2 left',
        },
        {
            input: [15, [2, 8, 3, 6]],
            expected: 2,
            isPublic: true,
            description: 'Durian seller with 15 durians and requests [2, 8, 3, 6] should have 2 left',
        },
        {
            input: [5, [10, 2, 3]],
            expected: 0,
            isPublic: true,
            description: 'Durian seller with 5 durians and requests [10, 2, 3] should have 0 left',
        },
        // Hidden test cases
        {
            input: [19, [5, 5, 5, 5]],
            expected: 4,
            isPublic: false,
            description: 'Nearly all durians sold: 19 durians with requests [5, 5, 5, 5] should have 4 left',
        },
        {
            input: [0, [1, 2, 3]],
            expected: 0,
            isPublic: false,
            description: 'Start with 0 durians, all requests should be skipped',
        },
        {
            input: [10, []],
            expected: 10,
            isPublic: false,
            description: 'No customers, all 10 durians should remain',
        },
        {
            input: [1, [1]],
            expected: 0,
            isPublic: false,
            description: 'Exact match: 1 durian for 1 request should leave 0',
        },
        {
            input: [1, [2]],
            expected: 1,
            isPublic: false,
            description: 'Request too large: 1 durian for 2 request should leave 1',
        },
        {
            input: [99, [50, 25, 25]],
            expected: 24,
            isPublic: false,
            description: 'Nearly perfect distribution: 99 durians with [50, 25, 25] should leave 24',
        },
        {
            input: [100, [60, 50]],
            expected: 40,
            isPublic: false,
            description: 'Second request too large: 100 with [60, 50] should leave 40',
        },
        {
            input: [7, [3, 3, 3]],
            expected: 1,
            isPublic: false,
            description: 'Last request partially unfulfilled: 7 with [3, 3, 3] should leave 1',
        },
        {
            input: [6, [7, 1, 1, 1, 1, 1]],
            expected: 1,
            isPublic: false,
            description: 'Skip first large request, serve most small ones: 6 with [7, 1, 1, 1, 1, 1] should leave 1',
        },
        {
            input: [4, [1, 1, 1, 1]],
            expected: 0,
            isPublic: false,
            description: 'Exact requests match: 4 with [1, 1, 1, 1] should leave 0',
        },
        {
            input: [50, [100]],
            expected: 50,
            isPublic: false,
            description: 'Single large request: 50 with [100] should leave 50',
        },
        {
            input: [25, [10, 10, 10]],
            expected: 5,
            isPublic: false,
            description: 'Partial fulfillment: 25 with [10, 10, 10] should leave 5',
        },
        {
            input: [9, [2, 2, 2, 2]],
            expected: 1,
            isPublic: false,
            description: 'Nearly evenly divisible: 9 with [2, 2, 2, 2] should leave 1',
        },
        {
            input: [12, [5, 10]],
            expected: 7,
            isPublic: false,
            description: 'Mixed fulfillment: 12 with [5, 10] should leave 7 (skip second)',
        },
        {
            input: [30, [15, 20, 5]],
            expected: 10,
            isPublic: false,
            description: 'Skip middle request: 30 with [15, 20, 5] should leave 10',
        },
        {
            input: [6, [3, 4]],
            expected: 3,
            isPublic: false,
            description: 'First served, second skipped: 6 with [3, 4] should leave 3',
        },
        {
            input: [2, [1, 1, 1]],
            expected: 0,
            isPublic: false,
            description: 'Two requests served: 2 with [1, 1, 1] should leave 0',
        },
    ],
    options: {
        type: 'JSON',
    },
};
